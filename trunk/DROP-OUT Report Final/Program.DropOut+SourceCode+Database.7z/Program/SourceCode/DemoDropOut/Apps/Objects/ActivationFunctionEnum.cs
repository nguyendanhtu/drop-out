﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoDropOut.Apps.Objects
{
    public enum ActivationFunctionEnum
    {
        Logistic = 0,
        HiperbolicTangent = 1,
    }
}
