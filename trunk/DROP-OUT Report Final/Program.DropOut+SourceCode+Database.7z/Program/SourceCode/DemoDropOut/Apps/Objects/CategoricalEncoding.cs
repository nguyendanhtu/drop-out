﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoDropOut.Apps.Objects
{
    public enum CategoricalEncoding
    {
        OneOfN = 0,
        Binary = 1,
        Numeric = 2,
    }
}
