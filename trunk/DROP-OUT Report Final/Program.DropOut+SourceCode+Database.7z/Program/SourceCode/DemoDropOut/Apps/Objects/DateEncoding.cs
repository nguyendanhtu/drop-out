﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoDropOut.Apps.Objects
{
    public enum DateEncoding
    {
        Weekly = 0,
        Monthly = 1,
        Yearly = 2,
    }
}
