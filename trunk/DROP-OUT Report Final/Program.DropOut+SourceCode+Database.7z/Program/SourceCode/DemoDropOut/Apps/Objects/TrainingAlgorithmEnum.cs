﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoDropOut.Apps.Objects
{
    public enum TrainingAlgorithmEnum
    {
        BackPropagation = 0,
        QuickPropagation = 1,
    }
}
