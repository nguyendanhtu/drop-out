﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using C1.Win.C1FlexGrid;
using System.Drawing;

namespace DemoDropOut.Common
{
    public struct C1Styles
    {
        public static void TrainingSet(CellStyle style)
        {
            style.ForeColor = Color.Blue;
        }

    }
}
