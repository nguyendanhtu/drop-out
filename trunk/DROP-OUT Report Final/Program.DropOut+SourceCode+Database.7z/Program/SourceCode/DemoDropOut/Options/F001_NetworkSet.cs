﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DemoDropOut
{
    public partial class F001_NetworkSet : Form
    {
        public F001_NetworkSet()
        {
            InitializeComponent();
        }
    }
}
